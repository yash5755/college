<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

$conn = new mysqli("localhost", "root", "", "college_db");

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST['action'] ?? 'register';
    
    if ($action === 'send_otp') {
        // Redirect to OTP handler for sending OTP
        $_POST['action'] = 'send_registration_otp';
        include 'otp_handler.php';
        exit;
    }
    
    if ($action === 'verify_otp') {
        // Redirect to OTP handler for OTP verification
        $_POST['action'] = 'verify_registration_otp';
        include 'otp_handler.php';
        exit;
    }
    
    // Legacy registration support (backward compatibility)
    $name = $_POST['name'] ?? '';
    $loginId = $_POST['loginId'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';
    $email = $_POST['email'] ?? '';

    // Prevent admin registration completely
    if ($role === 'admin') {
        echo json_encode(["status" => "error", "message" => "Admin registration is not allowed. Contact system administrator."]);
        exit;
    }

    // Email validation - everyone should have @vvce.ac.in domain
    if (!str_ends_with($email, '@vvce.ac.in')) {
        echo json_encode([
            "status" => "error", 
            "message" => "Please use your official college email ending with @vvce.ac.in"
        ]);
        exit;
    }

    // Teacher validation - check against authorized teacher email list
    if ($role === 'teacher') {
        // List of authorized teacher email prefixes (before @vvce.ac.in)
        $authorizedTeachers = [
            'giridarshan.sk',
            'prof.johnson', 
            'dr.wilson',
            'prof.davis',
            'dr.kumar',
            'prof.sharma',
            'dr.patel',
            'prof.reddy',
            'dr.singh',
            'prof.gupta',
            'hod.cse',
            'hod.ece',
            'hod.mech',
            'hod.civil',
            'dean.academics',
            'principal'
        ];
        
        // Extract email prefix (part before @vvce.ac.in)
        $emailPrefix = str_replace('@vvce.ac.in', '', $email);
        
        if (!in_array($emailPrefix, $authorizedTeachers)) {
            echo json_encode([
                "status" => "error", 
                "message" => "Teacher registration requires authorization. Your email is not in the approved faculty list. Please contact the administrator."
            ]);
            exit;
        }
    }

    // Guest/Student validation - strict USN format required
    if ($role === 'guest') {
        $emailPrefix = str_replace('@vvce.ac.in', '', $email);
        
        // Student emails must follow exact pattern: vvce[YY][DEPT][NNNN]
        // Example: vvce24cs0177, vvce23ec0045, vvce22me0123
        if (!preg_match('/^vvce[0-9]{2}[a-z]{2,4}[0-9]{4}$/', $emailPrefix)) {
            echo json_encode([
                "status" => "error", 
                "message" => "Student email must follow the format: vvce[year][dept][number]@vvce.ac.in (e.g., vvce24cs0177@vvce.ac.in)"
            ]);
            exit;
        }
    }

    // Check if user already exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE login_id = ? OR email = ?");
    $stmt->bind_param("ss", $loginId, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "User ID or Email already exists"]);
    } else {
        // Insert new user
        // $stmt = $conn->prepare("INSERT INTO users (name, login_id, password, role, //email) VALUES (?, ?, ?, ?, ?)");
        // For backward compatibility, register directly without OTP
        // In production, you might want to force OTP verification
        $stmt = $conn->prepare("INSERT INTO users (name, login_id, password, role, email, is_verified) VALUES (?, ?, ?, ?, ?, FALSE)");
        $stmt->bind_param("sssss", $name, $loginId, $password, $role, $email);
        
        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Registration successful! Please login with your credentials."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Registration failed: " . $stmt->error]);
        }
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}

$conn->close();
?>
