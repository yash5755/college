<?php
// Simple test file to verify everything works
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>System Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .test { margin: 20px 0; padding: 15px; border-radius: 5px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }
    </style>
</head>
<body>
    <h1>🔧 College Management System - Test Results</h1>
    
    <?php
    echo '<div class="test info"><strong>Testing Database Connection...</strong></div>';
    
    try {
        $pdo = new PDO("mysql:host=localhost;dbname=college_db;charset=utf8", "root", "");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo '<div class="test success">✅ Database connection successful!</div>';
        
        // Test tables
        $tables = ['users', 'otp_codes'];
        foreach ($tables as $table) {
            $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
            if ($stmt->rowCount() > 0) {
                echo "<div class='test success'>✅ Table '$table' exists</div>";
            } else {
                echo "<div class='test error'>❌ Table '$table' missing</div>";
            }
        }
        
        // Test API endpoint
        echo '<div class="test info"><strong>Testing API Endpoint...</strong></div>';

        // Get the current directory and construct the API URL
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $currentDir = dirname($_SERVER['REQUEST_URI']);
        $apiUrl = $protocol . '://' . $host . $currentDir . '/api.php';

        echo "<div class='test info'>Testing URL: $apiUrl</div>";

        // Check if api.php file exists locally first
        if (file_exists('api.php')) {
            echo '<div class="test success">✅ api.php file exists</div>';
            
            // Test by including the file directly
            $_POST['action'] = 'test_connection';
            ob_start();
            try {
                include 'api.php';
                $response = ob_get_clean();
                
                if ($response) {
                    $data = json_decode($response, true);
                    if ($data && isset($data['success']) && $data['success']) {
                        echo '<div class="test success">✅ API endpoint working via direct include!</div>';
                    } else {
                        echo '<div class="test error">❌ API response error: ' . ($response) . '</div>';
                    }
                } else {
                    echo '<div class="test error">❌ No response from API</div>';
                }
            } catch (Exception $e) {
                ob_end_clean();
                echo '<div class="test error">❌ API error: ' . $e->getMessage() . '</div>';
            }
            unset($_POST['action']);
        } else {
            echo '<div class="test error">❌ api.php file not found in current directory</div>';
            echo '<div class="test info">Current directory: ' . __DIR__ . '</div>';
            echo '<div class="test info">Looking for: ' . __DIR__ . '/api.php</div>';
        }
        
    } catch (Exception $e) {
        echo '<div class="test error">❌ Database error: ' . $e->getMessage() . '</div>';
        echo '<div class="test info">Make sure XAMPP MySQL is running and run the SQL setup script first.</div>';
    }
    ?>
    
    <div class="test info">
        <strong>📋 Setup Instructions:</strong><br>
        1. Make sure XAMPP is running (Apache + MySQL)<br>
        2. Run the SQL script in <code>scripts/complete_setup.sql</code><br>
        3. Access <code>index.html</code> to test the system<br>
        4. Use these test accounts:<br>
        &nbsp;&nbsp;• Admin: <code>admin</code> / <code>admin123</code><br>
        &nbsp;&nbsp;• Teacher: <code>teacher1</code> / <code>pass123</code><br>
        &nbsp;&nbsp;• Student: <code>student1</code> / <code>pass123</code>
    </div>
    
    <div class="test info">
        <strong>🧪 Test Registration:</strong><br>
        Try registering with email: <code>test@vvce.ac.in</code><br>
        The OTP will be displayed in the success message for testing.
    </div>
</body>
</html>
