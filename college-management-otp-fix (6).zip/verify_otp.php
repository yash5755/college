<?php
$conn = new mysqli("localhost", "root", "", "college_db");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$email = $_POST['email'];
$otp = $_POST['otp'];

$result = $conn->query("SELECT * FROM otp_requests WHERE email='$email' AND otp='$otp'");
$row = $result->fetch_assoc();

if ($row && strtotime($row['expires_at']) > time()) {
    $conn->query("UPDATE users SET is_verified = 1 WHERE email = '$email'");
    $conn->query("DELETE FROM otp_requests WHERE email = '$email'");
    echo "Email verified successfully!";
} else {
    echo "Invalid or expired OTP.";
}
?>
