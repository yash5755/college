<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Database connection
$conn = new mysqli("localhost", "root", "", "college_db");
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

$type = $_POST['type'] ?? ''; // 'registration' or 'forgot_password'
$email = $_POST['email'] ?? '';

// Validation
if (!$email || !$type) {
    echo json_encode(["status" => "error", "message" => "Email and type are required"]);
    exit;
}

// Email validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !str_ends_with($email, '@vvce.ac.in')) {
    echo json_encode(["status" => "error", "message" => "Please use a valid college email (@vvce.ac.in)"]);
    exit;
}

// Generate OTP
$otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
$expires_at = date("Y-m-d H:i:s", strtotime("+10 minutes"));

// For registration, store user data
$user_data = null;
if ($type === 'registration') {
    $name = $_POST['name'] ?? '';
    $loginId = $_POST['loginId'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';
    
    if (!$name || !$loginId || !$password || !$role) {
        echo json_encode(["status" => "error", "message" => "All fields are required"]);
        exit;
    }
    
    // Check if user already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE login_id = ? OR email = ?");
    $stmt->bind_param("ss", $loginId, $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "User ID or Email already exists"]);
        exit;
    }
    
    $user_data = json_encode([
        'name' => $name,
        'loginId' => $loginId,
        'password' => $password,
        'role' => $role,
        'email' => $email
    ]);
}

// For forgot password, check if user exists
if ($type === 'forgot_password') {
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        echo json_encode(["status" => "error", "message" => "No account found with this email"]);
        exit;
    }
}

// Clear existing OTPs for this email
$conn->query("DELETE FROM otp_requests WHERE email = '$email'");

// Insert new OTP
$stmt = $conn->prepare("INSERT INTO otp_requests (email, otp, type, user_data, expires_at) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $email, $otp, $type, $user_data, $expires_at);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "OTP sent successfully! Check your email.",
        "debug_otp" => $otp // For testing - remove in production
    ]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to generate OTP"]);
}

$conn->close();
?>
