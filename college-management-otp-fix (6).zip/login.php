<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

include 'config1.php'; // Use the existing connection

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $loginId = $_POST['id'] ?? '';
    $password = $_POST['password'] ?? '';

    // Check for default admin credentials first
    if ($loginId === 'admin' && $password === 'admin123') {
        echo json_encode([
            "status" => "success",
            "role" => "admin",
            "name" => "System Administrator"
        ]);
        exit;
    }

    // Check database for other users
    $stmt = $conn->prepare("SELECT * FROM users WHERE login_id = ?");
    if (!$stmt) {
        echo json_encode(["status" => "error", "message" => "Database error: " . $conn->error]);
        exit;
    }
    
    $stmt->bind_param("s", $loginId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if ($user['password'] === $password) {
            echo json_encode([
                "status" => "success",
                "role" => $user['role'],
                "name" => $user['name']
            ]);
        } else {
            echo json_encode(["status" => "error", "message" => "Incorrect password"]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "User not found"]);
    }
    
    $stmt->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}

$conn->close();
?>
