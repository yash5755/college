<?php
// Only set headers if this file is called directly
if (!defined('INCLUDED_FROM_OTHER_FILE')) {
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST');
    header('Access-Control-Allow-Headers: Content-Type');
}

// Add debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

use PHPMailer\PHPMailer\PHPMailer;
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

$conn = new mysqli("localhost", "root", "", "college_db");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

$action = $_POST['action'] ?? '';
$email = $_POST['email'] ?? '';

switch ($action) {
    case 'send_registration_otp':
        handleSendRegistrationOTP();
        break;
    case 'verify_registration_otp':
        handleVerifyRegistrationOTP();
        break;
    case 'send_forgot_password_otp':
        handleSendForgotPasswordOTP();
        break;
    case 'verify_forgot_password_otp':
        handleVerifyForgotPasswordOTP();
        break;
    case 'reset_password':
        handleResetPassword();
        break;
    default:
        // Legacy support for your original OTP handler
        if (!$action) {
            // Original simple OTP sending
            $otp = rand(100000, 999999);
            $expires = date("Y-m-d H:i:s", strtotime("+5 minutes"));

            $conn->query("DELETE FROM otp_requests WHERE email='$email'");
            $conn->query("INSERT INTO otp_requests (email, otp, expires_at) VALUES ('$email', '$otp', '$expires')");

            if (sendOTPEmail($email, $otp, 'Verification')) {
                echo json_encode(["status" => "success", "message" => "OTP sent successfully!", "debug_otp" => $otp]);
            } else {
                echo json_encode(["status" => "error", "message" => "Failed to send OTP"]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Invalid action: " . $action]);
        }
}

// Helper Functions
function generateOTP() {
    return str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
}

function isValidCollegeEmail($email) {
    return str_ends_with($email, '@vvce.ac.in');
}

function isAuthorizedTeacher($email) {
    $authorizedTeachers = [
        'giridarshan.sk@vvce.ac.in',
        'prof.johnson@vvce.ac.in', 
        'dr.wilson@vvce.ac.in',
        'prof.davis@vvce.ac.in',
        'dr.kumar@vvce.ac.in',
        'prof.sharma@vvce.ac.in',
        'dr.patel@vvce.ac.in',
        'prof.reddy@vvce.ac.in',
        'dr.singh@vvce.ac.in',
        'prof.gupta@vvce.ac.in',
        'hod.cse@vvce.ac.in',
        'hod.ece@vvce.ac.in',
        'hod.mech@vvce.ac.in',
        'hod.civil@vvce.ac.in',
        'dean.academics@vvce.ac.in',
        'principal@vvce.ac.in'
    ];
    
    return in_array($email, $authorizedTeachers);
}

function isValidStudentEmail($email) {
    $emailPrefix = str_replace('@vvce.ac.in', '', $email);
    return preg_match('/^vvce[0-9]{2}[a-z]{2,4}[0-9]{4}$/', $emailPrefix);
}

function handleSendRegistrationOTP() {
    global $conn;
    
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $loginId = $_POST['loginId'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';
    
    // Validation
    if (!$name || !$email || !$loginId || !$password || !$role) {
        echo json_encode(["status" => "error", "message" => "All fields are required"]);
        return;
    }
    
    // Prevent admin registration
    if ($role === 'admin') {
        echo json_encode(["status" => "error", "message" => "Admin registration not allowed"]);
        return;
    }
    
    // Email validation
    if (!isValidCollegeEmail($email)) {
        echo json_encode(["status" => "error", "message" => "Please use official college email (@vvce.ac.in)"]);
        return;
    }
    
    // Role-specific validation
    if ($role === 'teacher' && !isAuthorizedTeacher($email)) {
        echo json_encode([
            "status" => "error",
            "message" => "Teacher registration requires authorization. Your email is not in the approved faculty list."
        ]);
        return;
    }
    
    if ($role === 'guest' && !isValidStudentEmail($email)) {
        echo json_encode([
            "status" => "error",
            "message" => "Student email must follow the format: vvce[year][dept][number]@vvce.ac.in"
        ]);
        return;
    }
    
    // Check existing user
    $stmt = $conn->prepare("SELECT id FROM users WHERE login_id = ? OR email = ?");
    $stmt->bind_param("ss", $loginId, $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "User ID or Email already exists"]);
        return;
    }
    
    // Generate OTP using your exact method
    $otp = rand(100000, 999999);
    $expires = date("Y-m-d H:i:s", strtotime("+5 minutes"));
    $user_data = json_encode(['name' => $name, 'loginId' => $loginId, 'password' => $password, 'role' => $role, 'email' => $email]);
    
    // Clear existing OTPs for this email
    $conn->query("DELETE FROM otp_requests WHERE email='$email'");
    
    // Insert new OTP with user data
    $conn->query("INSERT INTO otp_requests (email, otp, expires_at, user_data) VALUES ('$email', '$otp', '$expires', '$user_data')");
    
    // Send OTP email
    if (sendOTPEmail($email, $otp, 'Registration Verification')) {
        echo json_encode([
            "status" => "success",
            "message" => "OTP sent to your email address. Please check your inbox.",
            "debug_otp" => $otp // Remove in production
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to send OTP email"]);
    }
}

function handleVerifyRegistrationOTP() {
    global $conn;
    
    $email = $_POST['email'] ?? '';
    $otp = $_POST['otp'] ?? '';
    
    if (!$email || !$otp) {
        echo json_encode(["status" => "error", "message" => "Email and OTP are required"]);
        return;
    }
    
    // Use your exact working verification logic
    $result = $conn->query("SELECT * FROM otp_requests WHERE email='$email' AND otp='$otp'");
    $row = $result->fetch_assoc();

    if ($row && strtotime($row['expires_at']) > time()) {
        // Get user data from the original registration attempt
        $userData = json_decode($row['user_data'] ?? '{}', true);
        
        if ($userData && isset($userData['name'])) {
            // Create user account using the stored data
            $stmt = $conn->prepare("INSERT INTO users (name, login_id, password, role, email, is_verified) VALUES (?, ?, ?, ?, ?, 1)");
            $stmt->bind_param("sssss", $userData['name'], $userData['loginId'], $userData['password'], $userData['role'], $userData['email']);
            
            if ($stmt->execute()) {
                // Clean up OTP
                $conn->query("DELETE FROM otp_requests WHERE email = '$email'");
                
                echo json_encode([
                    "status" => "success",
                    "message" => "Registration completed successfully! You can now login."
                ]);
            } else {
                echo json_encode(["status" => "error", "message" => "Failed to create user account: " . $conn->error]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "User data not found. Please try registration again."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid or expired OTP"]);
    }
}

function handleSendForgotPasswordOTP() {
    global $conn;
    
    $email = $_POST['email'] ?? '';
    
    if (!$email) {
        echo json_encode(["status" => "error", "message" => "Email is required"]);
        return;
    }
    
    // Check if user exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows === 0) {
        echo json_encode(["status" => "error", "message" => "No account found with this email address"]);
        return;
    }
    
    // Generate and store OTP
    $otp = generateOTP();
    $expires_at = date("Y-m-d H:i:s", strtotime("+10 minutes"));
    
    // Clear existing OTPs
    $conn->query("DELETE FROM otp_requests WHERE email = '$email'");
    
    // Insert new OTP
    $stmt = $conn->prepare("INSERT INTO otp_requests (email, otp, type, expires_at) VALUES (?, ?, 'forgot_password', ?)");
    $stmt->bind_param("sss", $email, $otp, $expires_at);
    
    if ($stmt->execute()) {
        if (sendOTPEmail($email, $otp, 'Password Reset')) {
            echo json_encode([
                "status" => "success",
                "message" => "Password reset OTP sent to your email address.",
                "debug_otp" => $otp // Remove in production
            ]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to send OTP email"]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Database error: " . $conn->error]);
    }
}

function handleVerifyForgotPasswordOTP() {
    global $conn;
    
    $email = $_POST['email'] ?? '';
    $otp = $_POST['otp'] ?? '';
    
    if (!$email || !$otp) {
        echo json_encode(["status" => "error", "message" => "Email and OTP are required"]);
        return;
    }
    
    // Verify OTP - Remove the verified = 0 condition
    $stmt = $conn->prepare("SELECT * FROM otp_requests WHERE email = ? AND otp = ? AND type = 'forgot_password' AND expires_at > NOW()");
    $stmt->bind_param("ss", $email, $otp);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        echo json_encode([
            "status" => "success",
            "message" => "OTP verified successfully. You can now reset your password."
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid or expired OTP"]);
    }
}

function handleResetPassword() {
    global $conn;
    
    $email = $_POST['email'] ?? '';
    $otp = $_POST['otp'] ?? '';
    $newPassword = $_POST['newPassword'] ?? '';
    
    if (!$email || !$otp || !$newPassword) {
        echo json_encode(["status" => "error", "message" => "All fields are required"]);
        return;
    }
    
    // Verify OTP one more time - Remove the verified = 0 condition
    $stmt = $conn->prepare("SELECT * FROM otp_requests WHERE email = ? AND otp = ? AND type = 'forgot_password' AND expires_at > NOW()");
    $stmt->bind_param("ss", $email, $otp);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Update password
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $newPassword, $email);
        
        if ($stmt->execute()) {
            // Clean up OTP
            $conn->query("DELETE FROM otp_requests WHERE email = '$email'");
            
            echo json_encode([
                "status" => "success",
                "message" => "Password reset successfully! You can now login with your new password."
            ]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to update password: " . $conn->error]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid or expired OTP"]);
    }
}

function sendOTPEmail($email, $otp, $purpose) {
    try {
        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'yashwanthr5755@gmail.com';
        $mail->Password = 'kavtltipivdluhww';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('yashachar246@gmail.com', 'VVCE CMS');
        $mail->addAddress($email);
        $mail->Subject = "Your OTP Code - $purpose";
        $mail->Body = "Your OTP for $purpose is: $otp\n\nThis OTP is valid for 10 minutes.\n\nVidyavardhaka College of Engineering";

        return $mail->send();
    } catch (Exception $e) {
        error_log("Email sending failed to $email: " . $e->getMessage());
        return false;
    }
}

// Only close connection if this file is called directly
if (!defined('INCLUDED_FROM_OTHER_FILE')) {
    $conn->close();
}
?>
