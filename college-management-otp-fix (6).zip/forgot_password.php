<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

include 'config1.php';

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'send_otp':
            $_POST['action'] = 'send_forgot_password_otp';
            include 'otp_handler.php';
            break;
            
        case 'verify_otp':
            $_POST['action'] = 'verify_forgot_password_otp';
            include 'otp_handler.php';
            break;
            
        case 'reset_password':
            $_POST['action'] = 'reset_password';
            include 'otp_handler.php';
            break;
            
        default:
            echo json_encode(["status" => "error", "message" => "Invalid action specified"]);
            break;
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
}

$conn->close();
?>
