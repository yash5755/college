<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Database connection
$conn = new mysqli("localhost", "root", "", "college_db");
if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

$action = $_POST['action'] ?? '';

try {
    switch($action) {
        case 'send_registration_otp':
            sendRegistrationOTP();
            break;
        case 'verify_registration_otp':
            verifyRegistrationOTP();
            break;
        case 'send_forgot_password_otp':
            sendForgotPasswordOTP();
            break;
        case 'verify_forgot_password_otp':
            verifyForgotPasswordOTP();
            break;
        case 'reset_password':
            resetPassword();
            break;
        default:
            throw new Exception("Invalid action");
    }
} catch(Exception $e) {
    echo json_encode(["success" => false, "message" => $e->getMessage()]);
}

function sendRegistrationOTP() {
    global $conn;
    
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $loginId = trim($_POST['loginId'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $role = trim($_POST['role'] ?? '');
    
    if (empty($name) || empty($email) || empty($loginId) || empty($password) || empty($role)) {
        throw new Exception("All fields are required");
    }
    
    if (!str_ends_with($email, '@vvce.ac.in')) {
        throw new Exception("Please use college email (@vvce.ac.in)");
    }
    
    // Check if user already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR login_id = ?");
    $stmt->bind_param("ss", $email, $loginId);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        throw new Exception("Email or Login ID already exists");
    }
    
    // Generate OTP
    $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    $expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));
    
    // Store user data
    $userData = json_encode([
        'name' => $name,
        'loginId' => $loginId,
        'password' => $password,
        'role' => $role,
        'email' => $email
    ]);
    
    // Clean old OTPs
    $conn->query("DELETE FROM otp_requests WHERE email = '$email'");
    
    // Insert new OTP
    $stmt = $conn->prepare("INSERT INTO otp_requests (email, otp, type, user_data, expires_at) VALUES (?, ?, 'registration', ?, ?)");
    $stmt->bind_param("ssss", $email, $otp, $userData, $expires_at);
    $stmt->execute();
    
    echo json_encode([
        "success" => true,
        "message" => "OTP sent successfully!",
        "debug_otp" => $otp, // For testing
        "email" => $email
    ]);
}

function verifyRegistrationOTP() {
    global $conn;
    
    $email = trim($_POST['email'] ?? '');
    $otp = trim($_POST['otp'] ?? '');
    
    if (empty($email) || empty($otp)) {
        throw new Exception("Email and OTP are required");
    }
    
    // Find valid OTP
    $stmt = $conn->prepare("SELECT * FROM otp_requests WHERE email = ? AND otp = ? AND type = 'registration' AND verified = 0 AND expires_at > NOW()");
    $stmt->bind_param("ss", $email, $otp);
    $stmt->execute();
    $result = $stmt->get_result();
    $otpRecord = $result->fetch_assoc();
    
    if (!$otpRecord) {
        throw new Exception("Invalid or expired OTP");
    }
    
    // Get user data
    $userData = json_decode($otpRecord['user_data'], true);
    
    // Create user account
    $stmt = $conn->prepare("INSERT INTO users (name, login_id, password, role, email, is_verified) VALUES (?, ?, ?, ?, ?, 1)");
    $stmt->bind_param("sssss", $userData['name'], $userData['loginId'], $userData['password'], $userData['role'], $userData['email']);
    $stmt->execute();
    
    // Mark OTP as verified
    $conn->query("UPDATE otp_requests SET verified = 1 WHERE id = " . $otpRecord['id']);
    
    echo json_encode([
        "success" => true,
        "message" => "Registration completed successfully! You can now login."
    ]);
}

function sendForgotPasswordOTP() {
    global $conn;
    
    $email = trim($_POST['email'] ?? '');
    
    if (empty($email)) {
        throw new Exception("Email is required");
    }
    
    // Check if user exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows === 0) {
        throw new Exception("No account found with this email");
    }
    
    // Generate OTP
    $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    $expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));
    
    // Clean old OTPs
    $conn->query("DELETE FROM otp_requests WHERE email = '$email'");
    
    // Insert new OTP
    $stmt = $conn->prepare("INSERT INTO otp_requests (email, otp, type, expires_at) VALUES (?, ?, 'forgot_password', ?)");
    $stmt->bind_param("sss", $email, $otp, $expires_at);
    $stmt->execute();
    
    echo json_encode([
        "success" => true,
        "message" => "Password reset OTP sent!",
        "debug_otp" => $otp, // For testing
        "email" => $email
    ]);
}

function verifyForgotPasswordOTP() {
    global $conn;
    
    $email = trim($_POST['email'] ?? '');
    $otp = trim($_POST['otp'] ?? '');
    
    if (empty($email) || empty($otp)) {
        throw new Exception("Email and OTP are required");
    }
    
    // Find valid OTP
    $stmt = $conn->prepare("SELECT * FROM otp_requests WHERE email = ? AND otp = ? AND type = 'forgot_password' AND verified = 0 AND expires_at > NOW()");
    $stmt->bind_param("ss", $email, $otp);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception("Invalid or expired OTP");
    }
    
    echo json_encode([
        "success" => true,
        "message" => "OTP verified! You can now reset your password."
    ]);
}

function resetPassword() {
    global $conn;
    
    $email = trim($_POST['email'] ?? '');
    $otp = trim($_POST['otp'] ?? '');
    $newPassword = trim($_POST['newPassword'] ?? '');
    
    if (empty($email) || empty($otp) || empty($newPassword)) {
        throw new Exception("All fields are required");
    }
    
    // Verify OTP again
    $stmt = $conn->prepare("SELECT * FROM otp_requests WHERE email = ? AND otp = ? AND type = 'forgot_password' AND verified = 0 AND expires_at > NOW()");
    $stmt->bind_param("ss", $email, $otp);
    $stmt->execute();
    $result = $stmt->get_result();
    $otpRecord = $result->fetch_assoc();
    
    if (!$otpRecord) {
        throw new Exception("Invalid or expired OTP");
    }
    
    // Update password
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
    $stmt->bind_param("ss", $newPassword, $email);
    $stmt->execute();
    
    // Mark OTP as used
    $conn->query("UPDATE otp_requests SET verified = 1 WHERE id = " . $otpRecord['id']);
    
    echo json_encode([
        "success" => true,
        "message" => "Password reset successfully!"
    ]);
}

$conn->close();
?>
