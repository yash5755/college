<?php
// Test file to check all connections
header('Content-Type: application/json');

echo "<h2>Connection Test Results</h2>";

// Test 1: Database Connection
echo "<h3>1. Database Connection Test</h3>";
try {
    include 'config1.php';
    if ($conn->connect_error) {
        echo "<p style='color: red;'>❌ Database connection failed: " . $conn->connect_error . "</p>";
        echo "<p>Make sure XAMPP MySQL is running and database 'college_db' exists.</p>";
    } else {
        echo "<p style='color: green;'>✅ Database connected successfully</p>";
        
        // Test if required tables exist
        $tables = ['users', 'otp_requests'];
        foreach ($tables as $table) {
            $result = $conn->query("SHOW TABLES LIKE '$table'");
            if ($result->num_rows > 0) {
                echo "<p style='color: green;'>✅ Table '$table' exists</p>";
            } else {
                echo "<p style='color: orange;'>⚠️ Table '$table' does not exist</p>";
            }
        }
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Database error: " . $e->getMessage() . "</p>";
}

// Test 2: PHPMailer
echo "<h3>2. PHPMailer Test</h3>";
if (file_exists('PHPMailer/PHPMailer.php')) {
    echo "<p style='color: green;'>✅ PHPMailer files found</p>";
    
    try {
        require 'PHPMailer/PHPMailer.php';
        require 'PHPMailer/SMTP.php';
        require 'PHPMailer/Exception.php';
        echo "<p style='color: green;'>✅ PHPMailer loaded successfully</p>";
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ PHPMailer error: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p style='color: red;'>❌ PHPMailer files not found</p>";
    echo "<p>Download PHPMailer and place it in the PHPMailer/ directory</p>";
}

// Test 3: File Permissions
echo "<h3>3. File Permissions Test</h3>";
$files = ['otp_handler.php', 'config1.php', 'register.php', 'forgot_password.php'];
foreach ($files as $file) {
    if (file_exists($file)) {
        if (is_readable($file)) {
            echo "<p style='color: green;'>✅ $file is readable</p>";
        } else {
            echo "<p style='color: red;'>❌ $file is not readable</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ $file does not exist</p>";
    }
}

// Test 4: PHP Extensions
echo "<h3>4. PHP Extensions Test</h3>";
$extensions = ['mysqli', 'openssl', 'curl'];
foreach ($extensions as $ext) {
    if (extension_loaded($ext)) {
        echo "<p style='color: green;'>✅ $ext extension loaded</p>";
    } else {
        echo "<p style='color: red;'>❌ $ext extension not loaded</p>";
    }
}

echo "<h3>5. Quick OTP Test</h3>";
echo "<p>Test OTP generation: " . str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT) . "</p>";
?>
