-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS college_db;
USE college_db;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    login_id VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'teacher', 'guest') NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    is_verified TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create OTP requests table
CREATE TABLE IF NOT EXISTS otp_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    type ENUM('registration', 'forgot_password') NOT NULL,
    user_data TEXT NULL,
    verified TINYINT(1) DEFAULT 0,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email_otp (email, otp),
    INDEX idx_expires (expires_at)
);

-- Insert default admin user if not exists
INSERT IGNORE INTO users (name, login_id, password, role, email, is_verified) 
VALUES ('System Administrator', 'admin', 'admin123', 'admin', 'admin@vvce.ac.in', 1);

-- Show tables to confirm creation
SHOW TABLES;
