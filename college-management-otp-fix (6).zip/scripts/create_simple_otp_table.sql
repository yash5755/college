-- Create the simple OTP table structure that matches your working files
USE college_db;

-- Drop existing table if it exists
DROP TABLE IF EXISTS otp_requests;

-- Create the table with user_data field for registration
CREATE TABLE otp_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    expires_at DATETIME NOT NULL,
    user_data TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

SELECT 'Simple OTP table created with user_data field!' as status;
