-- Complete database setup from scratch
DROP DATABASE IF EXISTS college_db;
CREATE DATABASE college_db;
USE college_db;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    login_id VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'teacher', 'guest') NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    is_verified TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- OTP table (FIXED)
CREATE TABLE otp_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    otp_code VARCHAR(6) NOT NULL,
    purpose ENUM('registration', 'password_reset') NOT NULL,
    user_data TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    is_used TINYINT(1) DEFAULT 0,
    INDEX idx_email_otp (email, otp_code),
    INDEX idx_expires (expires_at)
);

-- Insert admin user
INSERT INTO users (name, login_id, password, role, email, is_verified) 
VALUES ('Admin', 'admin', 'admin123', 'admin', 'admin@vvce.ac.in', 1);

-- Test data
INSERT INTO users (name, login_id, password, role, email, is_verified) 
VALUES 
('John Teacher', 'teacher1', 'pass123', 'teacher', 'john@vvce.ac.in', 1),
('Jane Student', 'student1', 'pass123', 'guest', 'vvce24cs0001@vvce.ac.in', 1);

SELECT 'Database setup complete!' as status;
