-- Update the OTP table to match your working structure
USE college_db;

-- Drop existing table if it has wrong structure
DROP TABLE IF EXISTS otp_requests;

-- Create the correct OTP table structure
CREATE TABLE otp_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    type ENUM('registration', 'forgot_password') DEFAULT NULL,
    user_data TEXT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email_otp (email, otp),
    INDEX idx_expires (expires_at)
);

SELECT 'OTP table updated to match your working structure!' as status;
