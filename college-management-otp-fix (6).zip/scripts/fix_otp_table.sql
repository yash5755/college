-- Fix the OTP table structure
USE college_db;

DROP TABLE IF EXISTS otp_requests;

CREATE TABLE otp_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    type ENUM('registration', 'forgot_password') NOT NULL,
    user_data TEXT NULL,
    verified TINYINT(1) DEFAULT 0,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email_otp (email, otp),
    INDEX idx_expires (expires_at)
);

SELECT 'OTP table fixed!' as status;
