// Global Variables
let currentUser = null
let userRole = null
let selectedAuthRole = null
let students = []
const rooms = []
const blocks = []
const timetable = []

// Wait for DOM to be fully loaded
document.addEventListener("DOMContentLoaded", () => {
  console.log("DOM fully loaded")

  // Initialize images without animations
  initializeImages()

  // Add event listeners for forms
  document.getElementById("loginFormElement").addEventListener("submit", (event) => {
    event.preventDefault()
    handleLogin()
  })

  document.getElementById("registerFormElement").addEventListener("submit", (event) => {
    event.preventDefault()
    handleRegister()
  })

  // Set default date to today for reservations
  const today = new Date().toISOString().split("T")[0]
  const dateInput = document.getElementById("reservationDate")
  if (dateInput) {
    dateInput.value = today
    dateInput.min = today // Prevent past dates
  }

  // Initialize time display
  updateCurrentTime()
  setInterval(updateCurrentTime, 60000)
})

// Image Loading Functions without animations
function initializeImages() {
  console.log("Initializing images...")

  // Load background image
  loadBackgroundImage()

  // Load logo images
  loadLogoImages()
}

function loadBackgroundImage() {
  const backgroundDiv = document.querySelector(".college-background")
  if (!backgroundDiv) {
    console.log("Background div not found")
    return
  }

  // Try to load the custom image
  const img = new Image()
  img.onload = () => {
    console.log("Background image loaded successfully")
    // Set directly without animation
    backgroundDiv.style.opacity = "1"
  }
  img.onerror = () => {
    console.log("Background image failed to load, using fallback")
    backgroundDiv.style.backgroundImage = "none"
  }
  img.src = "images/college-photo.jpg"
}

function loadLogoImages() {
  console.log("Attempting to load logo images...")

  // Load login page logo
  const loginLogo = document.querySelector(".logo-image")
  const loginFallback = document.querySelector(".logo-fallback")

  if (loginLogo && loginFallback) {
    console.log("Login logo elements found, loading...")

    // Set up error handler first
    loginLogo.onerror = () => {
      console.log("Login logo failed to load, showing fallback")
      loginLogo.style.display = "none"
      loginFallback.style.display = "flex"
    }

    // Set up success handler
    loginLogo.onload = () => {
      console.log("Login logo loaded successfully")
      loginLogo.style.display = "block"
      loginFallback.style.display = "none"
    }

    // Try to load the logo - start with the most common path
    loginLogo.src = "images/college-logo.png"
  }

  // Load header logo
  const headerLogo = document.querySelector(".header-logo-image")
  const headerFallback = document.querySelector(".header-logo-fallback")

  if (headerLogo && headerFallback) {
    console.log("Header logo elements found, loading...")

    // Set up error handler first
    headerLogo.onerror = () => {
      console.log("Header logo failed to load, showing fallback")
      headerLogo.style.display = "none"
      headerFallback.style.display = "flex"
    }

    // Set up success handler
    headerLogo.onload = () => {
      console.log("Header logo loaded successfully")
      headerLogo.style.display = "block"
      headerFallback.style.display = "none"
    }

    // Try to load the logo
    headerLogo.src = "images/college-logo.png"
  }
}

// Authentication Functions
function showAuthForm(role) {
  console.log("Showing auth form for role:", role)
  selectedAuthRole = role
  document.getElementById("roleSelection").style.display = "none"
  document.getElementById("loginForm").style.display = "block"

  const title = document.getElementById("loginTitle")
  const authTitle = document.getElementById("authTitle")
  const authSubtitle = document.getElementById("authSubtitle")
  const authToggle = document.getElementById("authToggle")

  title.textContent = `${role.charAt(0).toUpperCase() + role.slice(1)} Login`
  authTitle.textContent = `${role.charAt(0).toUpperCase() + role.slice(1)} Access`
  authSubtitle.textContent = "Please enter your credentials"

  // Hide registration option for admin
  if (role === "admin") {
    authToggle.style.display = "none"
    // Keep the standard credentials message
    authSubtitle.textContent = "Please enter your credentials"
  } else {
    authToggle.style.display = "block"
    authSubtitle.textContent = "Please enter your credentials"
  }
}

function hideAuthForm() {
  document.getElementById("roleSelection").style.display = "flex"
  document.getElementById("loginForm").style.display = "none"
  document.getElementById("registerForm").style.display = "none"
  document.getElementById("authTitle").textContent = "Welcome to College Management System"
  document.getElementById("authSubtitle").textContent = "Please select your role to continue"

  // Hide email hint
  const emailHint = document.getElementById("emailHint")
  if (emailHint) {
    emailHint.style.display = "none"
  }

  clearAuthForms()
}

function showLoginForm() {
  console.log("Showing login form")
  document.getElementById("registerForm").style.display = "none"
  document.getElementById("loginForm").style.display = "block"
}

function showRegisterForm() {
  if (selectedAuthRole === "admin") {
    alert("Admin registration is not allowed. Please contact system administrator.")
    return
  }

  document.getElementById("loginForm").style.display = "none"
  document.getElementById("registerForm").style.display = "block"
  document.getElementById("registerTitle").textContent =
    `${selectedAuthRole.charAt(0).toUpperCase() + selectedAuthRole.slice(1)} Registration`

  // Show email hints based on role
  const emailHint = document.getElementById("emailHint")
  emailHint.style.display = "block"

  if (selectedAuthRole === "teacher") {
    emailHint.innerHTML = `
      <small style="color: #2a5298; font-size: 0.8rem;">
        <i class="fas fa-info-circle"></i> Teacher registration requires pre-approved email:
        <br>• Must end with @vvce.ac.in
        <br>• Your email must be in the authorized faculty list
        <br><strong>Examples:</strong> yash@vvce.ac.in, principal@vvce.ac.in
      </small>
    `
  } else if (selectedAuthRole === "guest") {
    emailHint.innerHTML = `
      <small style="color: #2a5298; font-size: 0.8rem;">
        <i class="fas fa-info-circle"></i> Student email format (mandatory):
        <br>• Must be: vvce[year][dept][number]@vvce.ac.in
        <br>• <strong>Example:</strong> vvce24cse0177@vvce.ac.in
        <br>• Year: 24, 23, 22, etc.
        <br>• Dept: cs, ec, me, cv, etc.
        <br>• Number: 4-digit student number
      </small>
    `
  }
}

function clearAuthForms() {
  document.getElementById("loginId").value = ""
  document.getElementById("loginPassword").value = ""
  document.getElementById("registerName").value = ""
  document.getElementById("registerEmail").value = ""
  document.getElementById("registerLoginId").value = ""
  document.getElementById("registerPassword").value = ""
}

function handleLogin() {
  console.log("Handling login")
  const loginId = document.getElementById("loginId").value
  const password = document.getElementById("loginPassword").value

  // For testing purposes, allow direct login with admin credentials
  if (loginId === "admin" && password === "admin123") {
    console.log("Admin login successful")
    currentUser = { id: loginId, name: "System Administrator" }
    userRole = "admin"

    // Hide login screen and show main app
    document.getElementById("loginScreen").style.display = "none"
    document.getElementById("mainApp").style.display = "block"

    // Update UI based on role
    updateUIForRole()

    // Load initial data
    initializeApp()

    return
  }

  const formData = new FormData()
  formData.append("id", loginId)
  formData.append("password", password)

  fetch("login.php", {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.status === "success") {
        currentUser = { id: loginId, name: data.name }
        userRole = data.role

        // Hide login screen and show main app
        document.getElementById("loginScreen").style.display = "none"
        document.getElementById("mainApp").style.display = "block"

        // Update UI based on role
        updateUIForRole()

        // Load initial data
        initializeApp()

        // Show success message
        alert(`Welcome, ${data.name}!`)
      } else {
        alert(data.message || "Login failed. Please try again.")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      alert("Connection error. Please check if XAMPP is running and try again.")
    })
}

function handleRegister() {
  console.log("Handling register")
  const name = document.getElementById("registerName").value
  const email = document.getElementById("registerEmail").value
  const loginId = document.getElementById("registerLoginId").value
  const password = document.getElementById("registerPassword").value

  // Basic validation
  if (!name || !email || !loginId || !password) {
    alert("Please fill in all fields")
    return
  }

  console.log("Form data:", { name, email, loginId, password, role: selectedAuthRole })

  // Send OTP for registration using your exact register.php
  const formData = new FormData()
  formData.append("action", "send_otp")
  formData.append("name", name)
  formData.append("email", email)
  formData.append("loginId", loginId)
  formData.append("password", password)
  formData.append("role", selectedAuthRole)

  fetch("register.php", {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      console.log("OTP send response:", data)
      if (data.status === "success") {
        alert(data.message + (data.debug_otp ? ` (Debug - OTP: ${data.debug_otp})` : ""))
        showOtpVerificationDialog(email, "registration", { name, loginId, password })
      } else {
        alert(data.message || "Failed to send OTP. Please try again.")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      alert("Connection error. Please check if XAMPP is running and try again.")
    })
}

function showOtpVerificationDialog(email, type, userData = null) {
  // Create OTP dialog
  const dialog = document.createElement("div")
  dialog.id = "otpDialog"
  dialog.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
  `
  dialog.innerHTML = `
    <div style="
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      text-align: center;
      max-width: 400px;
      width: 90%;
    ">
      <h3 style="margin-bottom: 20px; color: #2a5298;">Enter OTP</h3>
      <p style="margin-bottom: 20px; color: #666;">
        We've sent a 6-digit OTP to<br><strong>${email}</strong>
      </p>
      <input type="text" id="otpInput" placeholder="Enter 6-digit OTP" 
        style="
          width: 100%;
          padding: 12px;
          border: 1px solid #ddd;
          border-radius: 5px;
          text-align: center;
          font-size: 18px;
          letter-spacing: 2px;
          margin-bottom: 20px;
        "
        maxlength="6">
      <div style="display: flex; gap: 10px; justify-content: center;">
        <button onclick="verifyOtp('${email}', '${type}', ${JSON.stringify(userData).replace(/"/g, "&quot;")})" 
          style="
            background: #2a5298;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
          ">Verify OTP</button>
        <button onclick="closeOtpDialog()" 
          style="
            background: #666;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
          ">Cancel</button>
      </div>
      <p style="margin-top: 15px; font-size: 12px; color: #666;">
        Didn't receive OTP? <a href="#" onclick="resendOtp('${email}', '${type}', ${JSON.stringify(userData).replace(/"/g, "&quot;")})" style="color: #2a5298;">Resend</a>
      </p>
    </div>
  `
  document.body.appendChild(dialog)
  document.getElementById("otpInput").focus()
}

function verifyOtp(email, type, userData) {
  const otp = document.getElementById("otpInput").value

  if (!otp || otp.length !== 6) {
    alert("Please enter a valid 6-digit OTP")
    return
  }

  const formData = new FormData()
  formData.append("action", "verify_otp")
  formData.append("email", email)
  formData.append("otp", otp)

  fetch("register.php", {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      console.log("OTP verification response:", data)
      if (data.status === "success") {
        closeOtpDialog()
        alert(data.message)
        showLoginForm()
        clearAuthForms()
      } else {
        alert(data.message || "OTP verification failed.")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      alert("Connection error. Please try again.")
    })
}

function resendOtp(email, type, userData) {
  if (type === "registration") {
    handleRegister() // This will resend the OTP
  } else if (type === "forgot_password") {
    sendForgotPasswordOtp(email)
  }
  closeOtpDialog()
}

function closeOtpDialog() {
  const dialog = document.getElementById("otpDialog")
  if (dialog) {
    dialog.remove()
  }
}

function showForgotPasswordDialog() {
  const dialog = document.createElement("div")
  dialog.id = "forgotPasswordDialog"
  dialog.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
  `
  dialog.innerHTML = `
    <div style="
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      text-align: center;
      max-width: 400px;
      width: 90%;
    ">
      <h3 style="margin-bottom: 20px; color: #2a5298;">Forgot Password</h3>
      <p style="margin-bottom: 20px; color: #666;">
        Enter your email address to receive an OTP for password reset
      </p>
      <input type="email" id="forgotEmail" placeholder="Enter your email" 
        style="
          width: 100%;
          padding: 12px;
          border: 1px solid #ddd;
          border-radius: 5px;
          margin-bottom: 20px;
        ">
      <div style="display: flex; gap: 10px; justify-content: center;">
        <button onclick="sendForgotPasswordOtpFromDialog()" 
          style="
            background: #2a5298;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
          ">Send OTP</button>
        <button onclick="closeForgotPasswordDialog()" 
          style="
            background: #666;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
          ">Cancel</button>
      </div>
    </div>
  `
  document.body.appendChild(dialog)
  document.getElementById("forgotEmail").focus()
}

function sendForgotPasswordOtpFromDialog() {
  const email = document.getElementById("forgotEmail").value

  if (!email) {
    alert("Please enter your email address")
    return
  }
  closeForgotPasswordDialog()
  sendForgotPasswordOtp(email)
}

function sendForgotPasswordOtp(email) {
  const formData = new FormData()
  formData.append("action", "send_forgot_password_otp")
  formData.append("email", email)

  fetch("otp_handler.php", {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.status === "success") {
        alert(data.message + (data.debug_otp ? ` (Debug - OTP: ${data.debug_otp})` : ""))
        showOtpVerificationDialog(email, "forgot_password")
      } else {
        alert(data.message || "Failed to send OTP.")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      alert("Connection error. Please try again.")
    })
}

function closeForgotPasswordDialog() {
  const dialog = document.getElementById("forgotPasswordDialog")
  if (dialog) {
    dialog.remove()
  }
}

function showPasswordResetDialog(email, otp) {
  const dialog = document.createElement("div")
  dialog.id = "passwordResetDialog"
  dialog.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 1000;
  `
  dialog.innerHTML = `
    <div style="
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      text-align: center;
      max-width: 400px;
      width: 90%;
    ">
      <h3 style="margin-bottom: 20px; color: #2a5298;">Reset Password</h3>
      <p style="margin-bottom: 20px; color: #666;">
        Enter your new password
      </p>
      <input type="password" id="newPassword" placeholder="New Password" 
        style="
          width: 100%;
          padding: 12px;
          border: 1px solid #ddd;
          border-radius: 5px;
          margin-bottom: 15px;
        ">
      <input type="password" id="confirmPassword" placeholder="Confirm Password" 
        style="
          width: 100%;
          padding: 12px;
          border: 1px solid #ddd;
          border-radius: 5px;
          margin-bottom: 20px;
        ">
      <div style="display: flex; gap: 10px; justify-content: center;">
        <button onclick="resetPassword('${email}', '${otp}')" 
          style="
            background: #2a5298;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
          ">Reset Password</button>
        <button onclick="closePasswordResetDialog()" 
          style="
            background: #666;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
          ">Cancel</button>
      </div>
    </div>
  `
  document.body.appendChild(dialog)
  document.getElementById("newPassword").focus()
}

function resetPassword(email, otp) {
  const newPassword = document.getElementById("newPassword").value
  const confirmPassword = document.getElementById("confirmPassword").value

  if (!newPassword || !confirmPassword) {
    alert("Please fill in both password fields")
    return
  }

  if (newPassword !== confirmPassword) {
    alert("Passwords don't match")
    return
  }

  if (newPassword.length < 6) {
    alert("Password must be at least 6 characters long")
    return
  }

  const formData = new FormData()
  formData.append("action", "reset_password")
  formData.append("email", email)
  formData.append("otp", otp)
  formData.append("newPassword", newPassword)

  fetch("otp_handler.php", {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.status === "success") {
        closePasswordResetDialog()
        alert(data.message)
        showLoginForm()
      } else {
        alert(data.message || "Password reset failed.")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      alert("Connection error. Please try again.")
    })
}

function closePasswordResetDialog() {
  const dialog = document.getElementById("passwordResetDialog")
  if (dialog) {
    dialog.remove()
  }
}

function logout() {
  console.log("Logging out")
  if (confirm("Are you sure you want to logout?")) {
    currentUser = null
    userRole = null
    selectedAuthRole = null

    // Show login screen and hide main app
    document.getElementById("loginScreen").style.display = "flex"
    document.getElementById("mainApp").style.display = "none"

    // Reset login form
    hideAuthForm()

    // Reset to dashboard
    showSection("dashboard")

    // Reinitialize images
    initializeImages()
  }
}

// UI Functions
function updateUIForRole() {
  console.log("Updating UI for role:", userRole)
  const userWelcome = document.getElementById("userWelcome")
  userWelcome.textContent = `Welcome, ${currentUser.name} (${userRole.charAt(0).toUpperCase() + userRole.slice(1)})`

  // Update navigation based on role
  const roomsNavBtn = document.getElementById("roomsNavBtn")
  const reservationsNavBtn = document.getElementById("reservationsNavBtn")
  const roomsDashCard = document.getElementById("roomsDashCard")
  const reservationsDashCard = document.getElementById("reservationsDashCard")

  if (userRole !== "admin") {
    roomsNavBtn.classList.add("disabled")
    roomsDashCard.classList.add("disabled")
  }

  if (userRole === "guest") {
    reservationsNavBtn.classList.add("disabled")
    reservationsDashCard.classList.add("disabled")
  }

  // Load room data for teachers to ensure availability works
  if (userRole === "teacher" || userRole === "admin") {
    loadRoomVacancy()
    populateBlockFilter()
    // Load blocks for teacher access
    loadBlocks()
  }
}

// Add a function to populate the block filter dropdown
function populateBlockFilter() {
  const blockFilter = document.getElementById("blockFilter")
  if (!blockFilter) return

  // Keep the "All Blocks" option
  blockFilter.innerHTML = '<option value="all">All Blocks</option>'

  fetch("get_blocks.php")
    .then((response) => response.json())
    .then((data) => {
      if (data.error) {
        console.error("Error:", data.error)
        return
      }

      data.forEach((block) => {
        const option = document.createElement("option")
        option.value = block.name
        option.textContent = block.name
        blockFilter.appendChild(option)
      })
    })
    .catch((error) => {
      console.error("Error loading blocks for filter:", error)
    })
}

// Update the initializeApp function to call populateBlockFilter
function initializeApp() {
  console.log("Initializing app")
  // Load initial data
  loadStudents()
  updateCurrentTime()
  populateBlockFilter()

  // Update time every minute
  setInterval(updateCurrentTime, 60000)
}

function showSection(sectionName) {
  console.log("Showing section:", sectionName)
  // Hide all sections
  const sections = document.querySelectorAll(".section")
  sections.forEach((section) => {
    section.classList.remove("active")
  })

  // Remove active class from all nav buttons
  const navButtons = document.querySelectorAll(".nav-btn")
  navButtons.forEach((btn) => {
    btn.classList.remove("active")
  })

  // Show selected section
  const targetSection = document.getElementById(sectionName)
  if (targetSection) {
    targetSection.classList.add("active")
  }

  // Add active class to corresponding nav button
  const activeNavBtn = document.querySelector(`[onclick="showSection('${sectionName}')"]`)
  if (activeNavBtn) {
    activeNavBtn.classList.add("active")
  }

  // Load section-specific data
  switch (sectionName) {
    case "students":
      loadStudents()
      break
    case "rooms":
      if (userRole === "admin") {
        loadRooms()
        loadBlocks()
        document.getElementById("roomsAccessDenied").style.display = "none"
        document.getElementById("roomsAdminContent").style.display = "block"
      } else {
        document.getElementById("roomsAccessDenied").style.display = "block"
        document.getElementById("roomsAdminContent").style.display = "none"
      }
      break
    case "reservations":
      if (userRole === "teacher" || userRole === "admin") {
        document.getElementById("reservationsAccessDenied").style.display = "none"
        document.getElementById("reservationsTeacherContent").style.display = "block"
        // Load blocks for teacher reservations
        loadBlocks()
      } else {
        document.getElementById("reservationsAccessDenied").style.display = "block"
        document.getElementById("reservationsTeacherContent").style.display = "none"
      }
      break
    case "timetable":
      loadTimetable()
      break
    case "room-vacancy":
      loadRoomVacancy()
      // Ensure block filter is populated
      if (
        !document.getElementById("blockFilter").children.length ||
        document.getElementById("blockFilter").children.length <= 1
      ) {
        populateBlockFilter()
      }
      break
  }
}

// Student Functions
function loadStudents() {
  console.log("Loading students")

  // For testing purposes, use mock data if fetch fails
  const mockStudents = [
    {
      usn: "1MS21CS001",
      name: "John Doe",
      email: "john@student.vce.edu",
      phone: "9876543210",
      department: "Computer Science",
      semester: 5,
      section: "A",
    },
    {
      usn: "1MS21CS002",
      name: "Jane Smith",
      email: "jane@student.vce.edu",
      phone: "9876543211",
      department: "Computer Science",
      semester: 5,
      section: "A",
    },
    {
      usn: "1MS21CS003",
      name: "Mike Johnson",
      email: "mike@student.vce.edu",
      phone: "9876543212",
      department: "Computer Science",
      semester: 3,
      section: "B",
    },
  ]

  fetch("get_students.php")
    .then((response) => response.json())
    .then((data) => {
      if (data.error) {
        console.error("Error:", data.error)
        alert("Error loading students: " + data.error)
        // Use mock data if there's an error
        displayStudents(mockStudents)
        return
      }

      students = data
      displayStudents(students)
    })
    .catch((error) => {
      console.error("Error loading students:", error)
      // Use mock data if fetch fails
      displayStudents(mockStudents)
    })
}

function displayStudents(studentData) {
  console.log("Displaying students:", studentData.length)
  const tbody = document.getElementById("studentsTableBody")
  tbody.innerHTML = ""

  studentData.forEach((student) => {
    const row = document.createElement("tr")
    row.innerHTML = `
            <td><strong>${student.usn}</strong></td>
            <td>${student.name}</td>
            <td>${student.department}</td>
            <td>${student.semester}</td>
            <td>${student.section}</td>
            <td>
                <div>${student.email}</div>
                <div style="color: #666; font-size: 0.9rem;">${student.phone}</div>
            </td>
        `
    tbody.appendChild(row)
  })
}

function searchStudents() {
  console.log("Searching students")
  const searchTerm = document.getElementById("studentSearch").value.toLowerCase()

  if (!students || students.length === 0) {
    console.log("No students data available for search")
    return
  }

  const filteredStudents = students.filter(
    (student) =>
      student.usn.toLowerCase().includes(searchTerm) ||
      student.name.toLowerCase().includes(searchTerm) ||
      student.department.toLowerCase().includes(searchTerm),
  )

  displayStudents(filteredStudents)
}

// Time Functions
function updateCurrentTime() {
  const now = new Date()
  const timeString = now.toLocaleString()

  const currentTimeElements = document.querySelectorAll("#currentTime, #vacancyCurrentTime")
  currentTimeElements.forEach((element) => {
    if (element) {
      element.textContent = timeString
    }
  })
}

// Room and Block Functions
function loadRooms() {
  console.log("Loading rooms...")

  fetch("get_rooms.php")
    .then((response) => response.json())
    .then((data) => {
      if (data.error) {
        console.error("Error:", data.error)
        return
      }

      const roomsTableBody = document.getElementById("roomsTableBody")
      roomsTableBody.innerHTML = ""

      data.forEach((room) => {
        const facilities = []
        if (room.hasProjector) facilities.push("Projector")
        if (room.hasAC) facilities.push("AC")

        const row = document.createElement("tr")
        row.innerHTML = `
          <td>${room.roomNumber}</td>
          <td>${room.block}</td>
          <td>${room.floor}</td>
          <td>${room.type}</td>
          <td>${room.capacity}</td>
          <td>${facilities.join(", ") || "None"}</td>
          <td>
            <button class="btn btn-secondary btn-sm" onclick="editRoom(${room.id})">Edit</button>
            <button class="btn btn-danger btn-sm" onclick="deleteRoom(${room.id})">Delete</button>
          </td>
        `
        roomsTableBody.appendChild(row)
      })
    })
    .catch((error) => {
      console.error("Error loading rooms:", error)
    })
}

function loadBlocks() {
  console.log("Loading blocks...")

  fetch("get_blocks.php")
    .then((response) => response.json())
    .then((data) => {
      if (data.error) {
        console.error("Error:", data.error)
        return
      }

      const blocksContainer = document.getElementById("blocksContainer")
      blocksContainer.innerHTML = ""

      // Also populate the block select dropdown for room addition
      const roomBlockSelect = document.getElementById("roomBlock")
      if (roomBlockSelect) {
        roomBlockSelect.innerHTML = '<option value="">Select Block</option>'
      }

      // And for reservations if it exists
      const reservationBlockSelect = document.getElementById("reservationBlock")
      if (reservationBlockSelect) {
        reservationBlockSelect.innerHTML = '<option value="all">All Blocks</option>'
      }

      data.forEach((block) => {
        // Add to blocks grid
        const blockCard = document.createElement("div")
        blockCard.className = "block-card"
        blockCard.innerHTML = `
          <h4>${block.name}</h4>
          <p>${block.floors} Floors</p>
          <p>${block.description || ""}</p>
        `
        blocksContainer.appendChild(blockCard)

        // Add to room block select dropdown
        if (roomBlockSelect) {
          const option = document.createElement("option")
          option.value = block.name
          option.textContent = block.name
          roomBlockSelect.appendChild(option)
        }

        // Add to reservation block select dropdown
        if (reservationBlockSelect) {
          const option = document.createElement("option")
          option.value = block.name
          option.textContent = block.name
          reservationBlockSelect.appendChild(option)
        }
      })
    })
    .catch((error) => {
      console.error("Error loading blocks:", error)
    })
}

// Enhanced Timetable Functions
function loadTimetable() {
  console.log("Loading timetable...")

  const semester = document.getElementById("timetableSemester").value
  const section = document.getElementById("timetableSection").value
  const department = document.getElementById("timetableDepartment").value

  console.log(`Fetching timetable for: Semester ${semester}, Section ${section}, Department ${department}`)

  const url = `get_timetable.php?semester=${semester}&section=${section}&department=${encodeURIComponent(department)}`
  console.log("Fetching URL:", url)

  fetch(url)
    .then((response) => response.json())
    .then((data) => {
      console.log("Timetable data received:", data)

      if (data.error) {
        console.error("Error:", data.error)
        showTimetableError("Error loading timetable: " + data.error)
        return
      }

      if (!data || data.length === 0) {
        console.log("No timetable data found")
        showTimetableError(`No timetable data available for ${department} Semester ${semester} Section ${section}`)
        return
      }

      displayTimetable(data)
    })
    .catch((error) => {
      console.error("Error loading timetable:", error)
      showTimetableError("Connection error while loading timetable. Please check if XAMPP is running.")
    })
}

function displayTimetable(data) {
  const timetableGrid = document.getElementById("timetableGrid")

  // Create timetable structure
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
  const timeSlots = [
    "8:30 - 9:30",
    "9:30 - 10:30",
    "11:00 - 12:00", // After break
    "12:00 - 1:00",
    "2:00 - 3:00", // After lunch
    "3:00 - 4:00",
  ]

  // Create empty timetable structure
  const timetableData = {}
  timeSlots.forEach((timeSlot) => {
    timetableData[timeSlot] = {}
    days.forEach((day) => {
      timetableData[timeSlot][day] = null
    })
  })

  // Fill in the timetable data
  data.forEach((entry) => {
    if (timetableData[entry.timeSlot] && timetableData[entry.timeSlot].hasOwnProperty(entry.day)) {
      timetableData[entry.timeSlot][entry.day] = entry
    }
  })

  // Generate the complete timetable HTML with breaks
  const tableHTML = `
    <div class="timetable-container">
      <table class="timetable-table">
        <thead>
          <tr>
            <th style="width: 120px;">Time / Day</th>
            ${days.map((day) => `<th>${day}</th>`).join("")}
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="time-slot">8:30 - 9:30</td>
            ${generateRowCells(timetableData["8:30 - 9:30"], days)}
          </tr>
          <tr>
            <td class="time-slot">9:30 - 10:30</td>
            ${generateRowCells(timetableData["9:30 - 10:30"], days)}
          </tr>
          <tr class="break-row">
            <td class="break-slot" colspan="6" style="background: #fff3cd; text-align: center; font-weight: bold; color: #856404;">
              BREAK (10:30 - 11:00)
            </td>
          </tr>
          <tr>
            <td class="time-slot">11:00 - 12:00</td>
            ${generateRowCells(timetableData["11:00 - 12:00"], days)}
          </tr>
          <tr>
            <td class="time-slot">12:00 - 1:00</td>
            ${generateRowCells(timetableData["12:00 - 1:00"], days)}
          </tr>
          <tr class="lunch-row">
            <td class="lunch-slot" colspan="6" style="background: #d1ecf1; text-align: center; font-weight: bold; color: #0c5460;">
              LUNCH BREAK (1:00 - 2:00)
            </td>
          </tr>
          <tr>
            <td class="time-slot">2:00 - 3:00</td>
            ${generateRowCells(timetableData["2:00 - 3:00"], days)}
          </tr>
          <tr>
            <td class="time-slot">3:00 - 4:00</td>
            ${generateRowCells(timetableData["3:00 - 4:00"], days)}
          </tr>
        </tbody>
      </table>
    </div>
  `

  timetableGrid.innerHTML = tableHTML
}

// Helper function to generate table cells for a row
function generateRowCells(rowData, days) {
  return days
    .map((day) => {
      const entry = rowData ? rowData[day] : null
      if (entry) {
        const typeClass =
          entry.type === "lab" ? "lab-slot" : entry.type === "tutorial" ? "tutorial-slot" : "theory-slot"
        return `
        <td>
          <div class="class-slot ${typeClass}">
            <div class="class-subject">${entry.subject}</div>
            <div class="class-teacher">${entry.teacher}</div>
            <div class="class-room">${entry.room}</div>
            ${entry.type !== "theory" ? `<div class="class-type">${entry.type.toUpperCase()}</div>` : ""}
          </div>
        </td>
      `
      } else {
        return `
        <td>
          <div class="free-slot">Free</div>
        </td>
      `
      }
    })
    .join("")
}

function showTimetableError(message) {
  const timetableGrid = document.getElementById("timetableGrid")
  timetableGrid.innerHTML = `
    <div style="text-align: center; padding: 3rem; background: #f8d7da; border-radius: 15px; color: #721c24; border: 1px solid #f5c6cb;">
      <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 1rem;"></i>
      <h3>Timetable Not Available</h3>
      <p>${message}</p>
      <p style="margin-top: 1rem; font-size: 0.9rem; opacity: 0.8;">
        Please check if the data exists in the database or contact the administrator.
      </p>
    </div>
  `
}

// Update filterTimetable to call loadTimetable
function filterTimetable() {
  console.log("Filtering timetable...")
  loadTimetable()
}

// Enhanced Room Vacancy Functions
function loadRoomVacancy() {
  console.log("Loading room vacancy...")

  // Get current time and day
  const now = new Date()
  const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
  const currentDay = days[now.getDay()]

  // Skip weekends
  if (currentDay === "Sunday" || currentDay === "Saturday") {
    document.getElementById("vacantCount").textContent = "N/A"
    document.getElementById("occupiedCount").textContent = "N/A"
    document.getElementById("totalCount").textContent = "N/A"

    const roomVacancyList = document.getElementById("roomVacancyList")
    roomVacancyList.innerHTML = `
      <div class="room-vacancy-item available">
        <div class="room-info">
          <h4>Weekend</h4>
          <div class="room-details">No classes scheduled on weekends</div>
        </div>
        <div class="room-status">
          <span class="badge badge-info">Weekend</span>
        </div>
      </div>
    `
    return
  }

  // Get current hour and minute
  const currentHour = now.getHours()
  const currentMinute = now.getMinutes()

  // Get selected block filter
  const blockFilter = document.getElementById("blockFilter").value

  // Fetch rooms
  fetch("get_rooms.php")
    .then((response) => response.json())
    .then((roomsData) => {
      if (roomsData.error) {
        console.error("Error:", roomsData.error)
        return
      }

      // Filter rooms by block if needed
      let rooms = roomsData
      if (blockFilter !== "all") {
        rooms = roomsData.filter((room) => room.block === blockFilter)
      }

      // Set total count
      document.getElementById("totalCount").textContent = rooms.length

      // Now fetch current timetable to check occupancy - OPTIMIZED VERSION
      // Instead of fetching all combinations, fetch only what we need
      const currentDepartment = "Computer Science" // Default to one department for now
      const currentSemester = 5 // Default semester
      const currentSection = "A" // Default section

      fetch(
        `get_timetable.php?semester=${currentSemester}&section=${currentSection}&department=${encodeURIComponent(currentDepartment)}`,
      )
        .then((response) => response.json())
        .then((timetableData) => {
          // Filter to only current day
          const todayClasses = Array.isArray(timetableData) ? timetableData.filter((cls) => cls.day === currentDay) : []

          // Check which rooms are currently occupied
          const occupiedRooms = new Set()

          todayClasses.forEach((cls) => {
            // Parse time slot to check if current time falls within it
            const [startTime, endTime] = cls.timeSlot.split(" - ")

            const [startHour, startMinute] = startTime.split(":").map(Number)
            const [endHour, endMinute] = endTime.split(":").map(Number)

            // Convert to minutes since midnight for easier comparison
            const currentTimeInMinutes = currentHour * 60 + currentMinute
            const startTimeInMinutes = startHour * 60 + startMinute
            const endTimeInMinutes = endHour * 60 + endMinute

            // Check if current time is within this time slot
            if (currentTimeInMinutes >= startTimeInMinutes && currentTimeInMinutes <= endTimeInMinutes) {
              // This class is happening now, mark the room as occupied
              occupiedRooms.add(cls.room)
            }
          })

          // Update counts
          document.getElementById("occupiedCount").textContent = occupiedRooms.size
          document.getElementById("vacantCount").textContent = rooms.length - occupiedRooms.size

          // Generate room vacancy list
          const roomVacancyList = document.getElementById("roomVacancyList")
          roomVacancyList.innerHTML = ""

          rooms.forEach((room) => {
            const isOccupied = occupiedRooms.has(room.roomNumber)
            const currentClass = isOccupied
              ? todayClasses.find((cls) => cls.room === room.roomNumber && cls.day === currentDay)
              : null

            const roomItem = document.createElement("div")
            roomItem.className = `room-vacancy-item ${isOccupied ? "occupied" : "available"}`

            const facilities = []
            if (room.hasProjector) facilities.push("Projector")
            if (room.hasAC) facilities.push("AC")

            roomItem.innerHTML = `
              <div class="room-info">
                <h4>${room.roomNumber}</h4>
                <div class="room-details">${room.block}, ${room.floor}${room.floor === 1 ? "st" : room.floor === 2 ? "nd" : room.floor === 3 ? "rd" : "th"} Floor | ${room.type} | Capacity: ${room.capacity}${facilities.length ? " | " + facilities.join(", ") : ""}</div>
              </div>
              <div class="room-status">
                ${
                  isOccupied
                    ? `<span class="badge badge-danger">Occupied</span>
                   <div>Subject: ${currentClass ? currentClass.subject : "Unknown"}</div>
                   <div>Teacher: ${currentClass ? currentClass.teacher : "Unknown"}</div>
                   <div>Time: ${currentClass ? currentClass.timeSlot : "Unknown"}</div>`
                    : `<span class="badge badge-success">Available</span>`
                }
              </div>
            `

            roomVacancyList.appendChild(roomItem)
          })
        })
        .catch((error) => {
          console.error("Error loading room vacancy:", error)
          // Fallback to mock data
          document.getElementById("vacantCount").textContent = "15"
          document.getElementById("occupiedCount").textContent = "10"
          document.getElementById("totalCount").textContent = "25"
        })
    })
    .catch((error) => {
      console.error("Error loading room vacancy:", error)
      // Fallback to mock data
      document.getElementById("vacantCount").textContent = "15"
      document.getElementById("occupiedCount").textContent = "10"
      document.getElementById("totalCount").textContent = "25"
    })
}

// Update filterRoomVacancy to call loadRoomVacancy
function filterRoomVacancy() {
  console.log("Filtering room vacancy...")
  loadRoomVacancy()
}

// Enhanced Student Finder Functions
function findStudent() {
  console.log("Finding student")
  const usn = document.getElementById("searchUSN").value
  if (!usn) {
    alert("Please enter a USN")
    return
  }

  // First find the student
  fetch("get_students.php")
    .then((response) => response.json())
    .then((studentsData) => {
      if (studentsData.error) {
        console.error("Error:", studentsData.error)
        return
      }

      const student = studentsData.find((s) => s.usn.toLowerCase() === usn.toLowerCase())

      if (!student) {
        alert("Student not found")
        document.getElementById("studentResult").style.display = "none"
        return
      }

      // Now get the student's timetable based on semester, section, and department
      fetch(
        `get_timetable.php?semester=${student.semester}&section=${student.section}&department=${encodeURIComponent(student.department)}`,
      )
        .then((response) => response.json())
        .then((timetableData) => {
          // Ensure timetableData is an array
          const timetable = Array.isArray(timetableData) ? timetableData : []

          // Get current day and time
          const now = new Date()
          const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
          const currentDay = days[now.getDay()]

          // Skip weekends
          if (currentDay === "Sunday" || currentDay === "Saturday") {
            displayStudentResult(student, null, "Weekend - No Classes")
            return
          }

          const currentHour = now.getHours()
          const currentMinute = now.getMinutes()
          const currentTimeInMinutes = currentHour * 60 + currentMinute

          // Find current class
          let currentClass = null
          let nextClass = null

          // Filter to today's classes
          const todayClasses = timetable.filter((cls) => cls.day === currentDay)

          // Sort by start time
          todayClasses.sort((a, b) => {
            const [aStartTime] = a.timeSlot.split(" - ")
            const [bStartTime] = b.timeSlot.split(" - ")

            const [aHour, aMinute] = aStartTime.split(":").map(Number)
            const [bHour, bMinute] = bStartTime.split(":").map(Number)

            const aTimeInMinutes = aHour * 60 + aMinute
            const bTimeInMinutes = bHour * 60 + bMinute

            return aTimeInMinutes - bTimeInMinutes
          })

          // Check each class
          for (const cls of todayClasses) {
            const [startTime, endTime] = cls.timeSlot.split(" - ")

            const [startHour, startMinute] = startTime.split(":").map(Number)
            const [endHour, endMinute] = endTime.split(":").map(Number)

            const startTimeInMinutes = startHour * 60 + startMinute
            const endTimeInMinutes = endHour * 60 + endMinute

            // Check if current time is within this time slot
            if (currentTimeInMinutes >= startTimeInMinutes && currentTimeInMinutes <= endTimeInMinutes) {
              currentClass = cls
              break
            }

            // If we haven't found the current class yet and this class is in the future,
            // it's the next class
            if (!currentClass && startTimeInMinutes > currentTimeInMinutes) {
              if (!nextClass) {
                nextClass = cls
              }
            }
          }

          displayStudentResult(student, currentClass, nextClass)
        })
        .catch((error) => {
          console.error("Error loading timetable:", error)
          displayStudentResult(student)
        })
    })
    .catch((error) => {
      console.error("Error finding student:", error)
      // If students array is empty, use mock data
      const mockStudent = {
        usn: usn,
        name: "John Doe",
        department: "Computer Science",
        semester: 5,
        section: "A",
      }
      displayStudentResult(mockStudent)
    })
}

// Update displayStudentResult to show current and next class
function displayStudentResult(student, currentClass = null, nextClass = null) {
  const resultDiv = document.getElementById("studentResult")

  let locationHTML = ""

  if (currentClass) {
    locationHTML = `
      <div class="location-card current">
        <h4><i class="fas fa-map-marker-alt"></i> Current Location</h4>
        <p>Based on current timetable, the student should be in:</p>
        <p><strong>Room ${currentClass.room}</strong></p>
        <p><strong>Subject:</strong> ${currentClass.subject}</p>
        <p><strong>Teacher:</strong> ${currentClass.teacher}</p>
        <p><strong>Time:</strong> ${currentClass.timeSlot}</p>
        ${currentClass.type !== "theory" ? `<p><strong>Type:</strong> ${currentClass.type.toUpperCase()}</p>` : ""}
      </div>
    `
  } else if (nextClass && typeof nextClass === "object") {
    locationHTML = `
      <div class="location-card next">
        <h4><i class="fas fa-clock"></i> Next Class</h4>
        <p>Student's next class will be:</p>
        <p><strong>Room ${nextClass.room}</strong></p>
        <p><strong>Subject:</strong> ${nextClass.subject}</p>
        <p><strong>Teacher:</strong> ${nextClass.teacher}</p>
        <p><strong>Time:</strong> ${nextClass.timeSlot}</p>
        ${nextClass.type !== "theory" ? `<p><strong>Type:</strong> ${nextClass.type.toUpperCase()}</p>` : ""}
      </div>
    `
  } else {
    locationHTML = `
      <div class="location-card none">
        <h4><i class="fas fa-info-circle"></i> No Classes</h4>
        <p>${typeof nextClass === "string" ? nextClass : "No classes scheduled for now or later today."}</p>
      </div>
    `
  }

  resultDiv.innerHTML = `
    <div class="student-info">
      <div class="info-item">
        <div class="info-label">USN</div>
        <div class="info-value">${student.usn}</div>
      </div>
      <div class="info-item">
        <div class="info-label">Name</div>
        <div class="info-value">${student.name}</div>
      </div>
      <div class="info-item">
        <div class="info-label">Department</div>
        <div class="info-value">${student.department}</div>
      </div>
      <div class="info-item">
        <div class="info-label">Semester</div>
        <div class="info-value">${student.semester}</div>
      </div>
      <div class="info-item">
        <div class="info-label">Section</div>
        <div class="info-value">${student.section}</div>
      </div>
    </div>
    ${locationHTML}
  `
  resultDiv.style.display = "block"
}

// Room Reservation Functions
function checkAvailability() {
  console.log("Checking room availability...")
  const date = document.getElementById("reservationDate").value
  const period = document.getElementById("reservationPeriod").value
  const block = document.getElementById("reservationBlock").value
  const purpose = document.getElementById("reservationPurpose").value

  if (!date || !period || !purpose) {
    alert("Please fill in all required fields")
    return
  }

  // Format the date for display
  const formattedDate = new Date(date).toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  // Mock available rooms for demonstration
  const mockAvailableRooms = [
    {
      roomNumber: "A101",
      block: "A Block",
      floor: 1,
      type: "Classroom",
      capacity: 60,
      hasProjector: true,
      hasAC: false,
    },
    {
      roomNumber: "B205",
      block: "B Block",
      floor: 2,
      type: "Laboratory",
      capacity: 40,
      hasProjector: true,
      hasAC: true,
    },
    {
      roomNumber: "C304",
      block: "C Block",
      floor: 3,
      type: "Seminar Hall",
      capacity: 100,
      hasProjector: true,
      hasAC: true,
    },
  ]

  // Filter by block if specified
  let availableRooms = mockAvailableRooms
  if (block !== "all") {
    availableRooms = mockAvailableRooms.filter((room) => room.block === block)
  }

  // Display available rooms
  const availableRoomsContainer = document.getElementById("availableRooms")
  availableRoomsContainer.style.display = "block"
  availableRoomsContainer.innerHTML = `
    <h3><i class="fas fa-door-open"></i> Available Rooms for ${formattedDate}, ${period}</h3>
    <p>Purpose: ${purpose}</p>
  `

  if (availableRooms.length === 0) {
    availableRoomsContainer.innerHTML += `
      <div style="text-align: center; padding: 2rem; background: #f8d7da; border-radius: 15px; color: #721c24; margin-top: 1rem;">
        <i class="fas fa-exclamation-triangle" style="font-size: 2rem; margin-bottom: 1rem;"></i>
        <h4>No Available Rooms</h4>
        <p>There are no available rooms matching your criteria. Please try different options.</p>
      </div>
    `
    return
  }

  availableRooms.forEach((room) => {
    const facilities = []
    if (room.hasProjector) facilities.push("Projector")
    if (room.hasAC) facilities.push("AC")

    const roomItem = document.createElement("div")
    roomItem.className = "available-room-item"
    roomItem.innerHTML = `
      <div class="room-details">
        <h4>${room.roomNumber}</h4>
        <p>${room.block}, ${room.floor}${room.floor === 1 ? "st" : room.floor === 2 ? "nd" : room.floor === 3 ? "rd" : "th"} Floor</p>
        <p>${room.type} | Capacity: ${room.capacity}</p>
        <p>Facilities: ${facilities.join(", ") || "None"}</p>
      </div>
      <div class="reserve-actions">
        <button class="instant-reserve-btn" onclick="reserveRoom('${room.roomNumber}', '${date}', '${period}', '${purpose}')">
          <i class="fas fa-check-circle"></i> Reserve Now
        </button>
      </div>
    `
    availableRoomsContainer.appendChild(roomItem)
  })
}

function reserveRoom(roomNumber, date, period, purpose) {
  console.log(`Reserving room ${roomNumber} on ${date} for ${period} for ${purpose}`)

  // Mock reservation success
  alert(`Room ${roomNumber} has been reserved successfully for ${period} on ${new Date(date).toLocaleDateString()}`)

  // Add to my reservations table
  const reservationsTableBody = document.getElementById("reservationsTableBody")
  const row = document.createElement("tr")

  // Format the date for display
  const formattedDate = new Date(date).toLocaleDateString()

  row.innerHTML = `
    <td>${roomNumber}</td>
    <td>${formattedDate}, ${period}</td>
    <td>${purpose}</td>
    <td><span class="badge badge-success">Confirmed</span></td>
    <td>
      <button class="btn btn-danger btn-sm" onclick="cancelReservation(this)">
        <i class="fas fa-times"></i> Cancel
      </button>
    </td>
  `
  reservationsTableBody.appendChild(row)
}

function cancelReservation(button) {
  if (confirm("Are you sure you want to cancel this reservation?")) {
    const row = button.closest("tr")
    row.remove()
  }
}

// Add these functions to prevent errors
function hideAddBlockForm() {
  document.getElementById("addBlockForm").style.display = "none"
}

function hideAddRoomForm() {
  document.getElementById("addRoomForm").style.display = "none"
}

function addBlock(event) {
  event.preventDefault()
  alert("Block added successfully!")
  hideAddBlockForm()
}

function addRoom(event) {
  event.preventDefault()
  alert("Room added successfully!")
  hideAddRoomForm()
}

// Console log to verify script is loaded
console.log("Script loaded successfully")
