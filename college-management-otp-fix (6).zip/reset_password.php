<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Database connection
$conn = new mysqli("localhost", "root", "", "college_db");
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed"]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    exit;
}

$email = $_POST['email'] ?? '';
$otp = $_POST['otp'] ?? '';
$newPassword = $_POST['newPassword'] ?? '';

if (!$email || !$otp || !$newPassword) {
    echo json_encode(["status" => "error", "message" => "All fields are required"]);
    exit;
}

// Verify OTP one more time
$stmt = $conn->prepare("SELECT * FROM otp_requests WHERE email = ? AND otp = ? AND type = 'forgot_password' AND expires_at > NOW()");
$stmt->bind_param("ss", $email, $otp);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Update password
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
    $stmt->bind_param("ss", $newPassword, $email);
    
    if ($stmt->execute()) {
        // Clean up OTP
        $conn->query("DELETE FROM otp_requests WHERE email = '$email'");
        echo json_encode([
            "status" => "success",
            "message" => "Password reset successfully! You can now login."
        ]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update password"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid or expired OTP"]);
}

$conn->close();
?>
