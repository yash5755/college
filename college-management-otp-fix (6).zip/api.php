<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once 'config.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    switch($action) {
        case 'send_registration_otp':
            sendRegistrationOTP();
            break;
        case 'verify_registration_otp':
            verifyRegistrationOTP();
            break;
        case 'send_password_reset_otp':
            sendPasswordResetOTP();
            break;
        case 'verify_password_reset_otp':
            verifyPasswordResetOTP();
            break;
        case 'reset_password':
            resetPassword();
            break;
        case 'login':
            handleLogin();
            break;
        case 'test_connection':
            testConnection();
            break;
        default:
            throw new Exception("Invalid action: " . $action);
    }
} catch(Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage(),
        "debug" => [
            "action" => $action,
            "post_data" => $_POST,
            "error" => $e->getTraceAsString()
        ]
    ]);
}

function testConnection() {
    global $pdo;
    echo json_encode([
        "success" => true,
        "message" => "Database connection successful!",
        "timestamp" => date('Y-m-d H:i:s')
    ]);
}

function sendRegistrationOTP() {
    global $pdo;
    
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $loginId = trim($_POST['loginId'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $role = trim($_POST['role'] ?? '');
    
    // Validation
    if (empty($name) || empty($email) || empty($loginId) || empty($password) || empty($role)) {
        throw new Exception("All fields are required");
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Invalid email format");
    }
    
    if (!str_ends_with($email, '@vvce.ac.in')) {
        throw new Exception("Please use college email (@vvce.ac.in)");
    }
    
    // Check if user already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR login_id = ?");
    $stmt->execute([$email, $loginId]);
    if ($stmt->fetch()) {
        throw new Exception("Email or Login ID already exists");
    }
    
    // Generate OTP
    $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    $expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));
    
    // Store user data for later
    $userData = json_encode([
        'name' => $name,
        'loginId' => $loginId,
        'password' => $password,
        'role' => $role,
        'email' => $email
    ]);
    
    // Clean old OTPs
    $pdo->prepare("DELETE FROM otp_codes WHERE email = ?")->execute([$email]);
    
    // Insert new OTP
    $stmt = $pdo->prepare("INSERT INTO otp_codes (email, otp_code, purpose, user_data, expires_at) VALUES (?, ?, 'registration', ?, ?)");
    $stmt->execute([$email, $otp, $userData, $expires_at]);
    
    echo json_encode([
        "success" => true,
        "message" => "OTP sent successfully! Please check your email.",
        "debug_otp" => $otp, // For testing only
        "email" => $email
    ]);
}

function verifyRegistrationOTP() {
    global $pdo;
    
    $email = trim($_POST['email'] ?? '');
    $otp = trim($_POST['otp'] ?? '');
    
    if (empty($email) || empty($otp)) {
        throw new Exception("Email and OTP are required");
    }
    
    // Find valid OTP
    $stmt = $pdo->prepare("SELECT * FROM otp_codes WHERE email = ? AND otp_code = ? AND purpose = 'registration' AND is_used = 0 AND expires_at > NOW()");
    $stmt->execute([$email, $otp]);
    $otpRecord = $stmt->fetch();
    
    if (!$otpRecord) {
        throw new Exception("Invalid or expired OTP");
    }
    
    // Get user data
    $userData = json_decode($otpRecord['user_data'], true);
    
    // Create user account
    $stmt = $pdo->prepare("INSERT INTO users (name, login_id, password, role, email, is_verified) VALUES (?, ?, ?, ?, ?, 1)");
    $stmt->execute([
        $userData['name'],
        $userData['loginId'],
        $userData['password'],
        $userData['role'],
        $userData['email']
    ]);
    
    // Mark OTP as used
    $pdo->prepare("UPDATE otp_codes SET is_used = 1 WHERE id = ?")->execute([$otpRecord['id']]);
    
    echo json_encode([
        "success" => true,
        "message" => "Registration completed successfully! You can now login."
    ]);
}

function sendPasswordResetOTP() {
    global $pdo;
    
    $email = trim($_POST['email'] ?? '');
    
    if (empty($email)) {
        throw new Exception("Email is required");
    }
    
    // Check if user exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if (!$stmt->fetch()) {
        throw new Exception("No account found with this email");
    }
    
    // Generate OTP
    $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    $expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));
    
    // Clean old OTPs
    $pdo->prepare("DELETE FROM otp_codes WHERE email = ?")->execute([$email]);
    
    // Insert new OTP
    $stmt = $pdo->prepare("INSERT INTO otp_codes (email, otp_code, purpose, expires_at) VALUES (?, ?, 'password_reset', ?)");
    $stmt->execute([$email, $otp, $expires_at]);
    
    echo json_encode([
        "success" => true,
        "message" => "Password reset OTP sent successfully!",
        "debug_otp" => $otp, // For testing only
        "email" => $email
    ]);
}

function verifyPasswordResetOTP() {
    global $pdo;
    
    $email = trim($_POST['email'] ?? '');
    $otp = trim($_POST['otp'] ?? '');
    
    if (empty($email) || empty($otp)) {
        throw new Exception("Email and OTP are required");
    }
    
    // Find valid OTP
    $stmt = $pdo->prepare("SELECT * FROM otp_codes WHERE email = ? AND otp_code = ? AND purpose = 'password_reset' AND is_used = 0 AND expires_at > NOW()");
    $stmt->execute([$email, $otp]);
    $otpRecord = $stmt->fetch();
    
    if (!$otpRecord) {
        throw new Exception("Invalid or expired OTP");
    }
    
    echo json_encode([
        "success" => true,
        "message" => "OTP verified! You can now reset your password.",
        "otp_id" => $otpRecord['id']
    ]);
}

function resetPassword() {
    global $pdo;
    
    $email = trim($_POST['email'] ?? '');
    $otp = trim($_POST['otp'] ?? '');
    $newPassword = trim($_POST['newPassword'] ?? '');
    
    if (empty($email) || empty($otp) || empty($newPassword)) {
        throw new Exception("All fields are required");
    }
    
    if (strlen($newPassword) < 6) {
        throw new Exception("Password must be at least 6 characters long");
    }
    
    // Verify OTP again
    $stmt = $pdo->prepare("SELECT * FROM otp_codes WHERE email = ? AND otp_code = ? AND purpose = 'password_reset' AND is_used = 0 AND expires_at > NOW()");
    $stmt->execute([$email, $otp]);
    $otpRecord = $stmt->fetch();
    
    if (!$otpRecord) {
        throw new Exception("Invalid or expired OTP");
    }
    
    // Update password
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
    $stmt->execute([$newPassword, $email]);
    
    // Mark OTP as used
    $pdo->prepare("UPDATE otp_codes SET is_used = 1 WHERE id = ?")->execute([$otpRecord['id']]);
    
    echo json_encode([
        "success" => true,
        "message" => "Password reset successfully! You can now login with your new password."
    ]);
}

function handleLogin() {
    global $pdo;
    
    $loginId = trim($_POST['loginId'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($loginId) || empty($password)) {
        throw new Exception("Login ID and password are required");
    }
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login_id = ? AND password = ?");
    $stmt->execute([$loginId, $password]);
    $user = $stmt->fetch();
    
    if (!$user) {
        throw new Exception("Invalid login credentials");
    }
    
    echo json_encode([
        "success" => true,
        "message" => "Login successful",
        "user" => [
            "id" => $user['id'],
            "name" => $user['name'],
            "role" => $user['role'],
            "email" => $user['email']
        ]
    ]);
}
?>
