<?php
$servername = "localhost";      // XAMPP runs MySQL on localhost
$username = "root";             // Default MySQL user in XAMPP
$password = "";                 // No password by default
$dbname = "college_db";         // Change this to your actual database name

$conn = new mysqli($servername, $username, $password, $dbname);
?>
